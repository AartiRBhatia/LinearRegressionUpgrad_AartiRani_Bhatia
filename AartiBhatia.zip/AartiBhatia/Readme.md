=========================================
Dataset characteristics
=========================================	

1. Notebook
2.Assignemnt
3.Readme
